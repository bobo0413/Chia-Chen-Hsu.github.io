# Assignment 01 — Add a CV page

1. Create a new file called `cv.qmd`
2. Add it to the navbar in `_quarto.yml`
3. Add a short CV section (Education, Experience, Skills)
4. Render and push
